# Sample JAR Builder (Windows)

## How to Build
1. Install Java JDK (must include javac)
2. Open CMD in this folder
3. Run:
   build_jar.cmd

## How to Run
java -jar sample.jar 1   → prints 1  
java -jar sample.jar 0   → prints 0  
java -jar sample.jar abc → prints 0  
