public class Sample {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println(0);
            return;
        }
        if (args[0].equals("1")) {
            System.out.println(1);
        } else {
            System.out.println(0);
        }
    }
}
